﻿# Tutor Question Generation Runtime

This workspace is dedicated to AI question generation for Tutor.

The runtime uses a main-orchestrator / subagent architecture:
- `question-orchestrator` talks with the teacher, confirms the teacher-controlled spec, and routes work.
- `spec-normalizer` turns teacher intent into `edu-question-spec.v1` and identifies missing fields.
- `text-question-generator` generates text-only questions.
- `visual-question-generator` generates image-grounded questions and Manim code.
- `text-question-evaluator` evaluates text-only questions.
- `visual-question-evaluator` evaluates image questions, image relevance, and Manim render safety.
- `student-simulator` and `profile-evolution` provide optional personalization/profile signals.

Human-controlled fields must come from the teacher/business request, not from AI: knowledge point, difficulty, question type, content mode, algorithm, and image requirement.

The service calling this runtime is responsible for final API validation, rendering, persistence, and request logging.
